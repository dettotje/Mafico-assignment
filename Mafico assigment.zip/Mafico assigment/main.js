//General idea: The idea is that the model gets restructered and the articles are sorted based on its producer, to me this gives a nice overview of the articles and gives room for if new articles/producers gets added.
//The new model will be put in Excel since that has a nice overview, but as a secondary alternative I also chose to make seperate JSON-files based on the producer since JSON file are less limited in further usage than xlsx files.
//The code has been made in such a way that if new producers gets added, it will produce a new map entry, tab in the sheet and JSON file.
//I chose JS in this case because, together with the XLSX library, I felt confident this was the closest I could get to writing this in a structure that was not far removed from typescript. 
//I could have chosen typescript, but I didnt feel confident with that yet to do this assignment with that language.


//Load in the sheetjs extension for reading in the SnelStart excel sheet, and fs for writing the JSON file
var XLSX = require("xlsx");
const fs = require('fs')

//Declare your variables for getting the data out, exsisting of a iterator and a array for a json layout of each file to be used later for the restructuring.
var SheetData = []
var Sheetiterator = 0;

//Read the file and load them into the SheetData array for easier row differentation.
var readExcelFile = XLSX.readFile("AssessmentFerry.xlsx");
readExcelFile.SheetNames.forEach(function(sheetName) 
{
  var XL_row_object = XLSX.utils.sheet_to_row_object_array(readExcelFile.Sheets[sheetName]);
  SheetData[Sheetiterator] = JSON.stringify(XL_row_object);
  Sheetiterator++
})

//Declare the data structures needed to sort the articles at groupId/producer level.
var NewSheetsByGroupID = new Map();
var Articles = [];
var ArticleData = [];
var ArticlesToBePutInMap = [];

//Declare a few iterators to loop through the maps and arrays, one for the articles array, one for the sheetdata and one for the producerdata.
var ArticlePerSheetIterator = 0;
var ProducerIterator = 0;
var ArticlesInsideArrayIterator = 0;

//For convenience sake, parse the sheets into separate variables.
var FirstPageDataJSON = JSON.parse(SheetData[0]);
var SecondPageDataJSON = JSON.parse(SheetData[1]);
//The third page will only be used for new sheets, since the groupId and producer will be used as a tab.
var ThirdPageDataJSON = JSON.parse(SheetData[2]);
var FourthPageDataJSON = JSON.parse(SheetData[3]);

//In the case of the reading of the three separate sheets, I had 2 choices: make nested for loops to account for the different sheets or depend upon the fact that each Article is put on the same place in each sheet. 
//Since the assignment stated that data can be put in hardcoded and since it seems that SnelStart puts the data at the same place on each sheet, I chose the former option for efficiency sake.
for(; ArticlePerSheetIterator != FirstPageDataJSON.length; ArticlePerSheetIterator++ )
{
  //Check if the map already contains this article to avoid duplication.
    if(Articles.indexOf(FirstPageDataJSON[ArticlePerSheetIterator].ArtikelCode) == -1)
     {
    //for readability, put all pushes from each page on a seperate line
    ArticleData.push(FirstPageDataJSON[ArticlePerSheetIterator].ID,FirstPageDataJSON[ArticlePerSheetIterator].Omschrijving,FirstPageDataJSON[ArticlePerSheetIterator].ArtikelOmzetGroepID, FirstPageDataJSON[ArticlePerSheetIterator].ArtikelCode)
    ArticleData.push(SecondPageDataJSON[ArticlePerSheetIterator].Adviesprijs,SecondPageDataJSON[ArticlePerSheetIterator].AdviesPrijsExclusiefBTW, SecondPageDataJSON[ArticlePerSheetIterator].Merknaam)
    ArticleData.push(FourthPageDataJSON[ArticlePerSheetIterator].ID, FourthPageDataJSON[ArticlePerSheetIterator].VanafAantal,FourthPageDataJSON[ArticlePerSheetIterator].Korting)
    //Stringify the array in advance for putting it in the excel sheet later
    //Push the data in array of articles. The type of this array is used later as the type for the second key for the NewSheetsByGroupID map.
    Articles.push(ArticleData)
    //Empty the array for the next iteration
    ArticleData = [];
     }
}

//In these for-loops, we will put the article data in the appropiate producer map.
for(ProducerIterator in ThirdPageDataJSON)
{
  //Check if the map already contains this group ID to avoid duplication.
  if(NewSheetsByGroupID.has(ThirdPageDataJSON[ProducerIterator].ID) != true)
  {
    //In this for loop, the article gets checked for the group ID, and put into the map if it matches.
    for(;ArticlesInsideArrayIterator != Articles.length;ArticlesInsideArrayIterator++)
    {
      //Check the article's GroupID with the current GroupID
      if(Articles[ArticlesInsideArrayIterator][2]== ThirdPageDataJSON[ProducerIterator].ID)
      {
       //The article gets pushed inside the array with the articles that will be put as the second key of the NewSheetsByGroupID map, which as can be seen here is an array of articles.
        ArticlesToBePutInMap.push(Articles[ArticlesInsideArrayIterator]);
      }
    }
    //Put the loaded array inside the map and empty the array for the next iteration.
    NewSheetsByGroupID.set(ThirdPageDataJSON[ProducerIterator].ID, ArticlesToBePutInMap)
    ArticlesToBePutInMap = [];
  }
  //Reset the iterator for the next iteration
  ArticlesInsideArrayIterator = 0
}

//Make the new structure as an object.
var NewDataStructure = XLSX.utils.book_new()
//Make new sheets with the new structure, using the producer data as exceltab ID's.
for (const [key, value] of NewSheetsByGroupID) 
{
  //Create new custom headers for the new structure.
  let Heading = [['ID', 'Omschrijving', 'ArtikelOmzetGroepID', 'ArtikelCode', 'Adviesprijs', 'AdviesPrijsExclusiefBTW', 'Merknaam',  'ArtikelVerkoopPrijsD', 'VanafAantal', 'Korting']];
  //Get the map entry from  the map to be put in the sheet.
  var CurrentMapValues = NewSheetsByGroupID.get(key)
  //Make a new sheet.
  var NewSheet = XLSX.utils.json_to_sheet(CurrentMapValues, {skipHeader: false} );
  //Add the custom headers.
  XLSX.utils.sheet_add_aoa(NewSheet, Heading);
  //Put the new sheet inside the new data structure, with the groupid and producer name as tab-name.
  XLSX.utils.book_append_sheet(NewDataStructure, NewSheet, `${key}` + "-" + `${value[0][6]}`);
  //As an extra structure, I make Json files here with the entries based on producer name.
  if (fs.existsSync(`${value[0][6]}.json`)) {
    fs.unlinkSync(`${value[0][6]}.json`)
  }
  fs.writeFileSync(`${value[0][6]}.json`, JSON.stringify(CurrentMapValues, null, 1, {flag: 'a'}))
}
//Create the Excel-file with the given Excel-structure.
XLSX.writeFile(NewDataStructure, "NewDataStructure.xlsx")
